# Fodrász Időpontfoglaló Rendszer

Ez a projekt egy fodrász időpontfoglaló rendszer, amely lehetővé teszi a vendégek számára az online időpontfoglalást, valamint az adminisztrátor számára a foglalások kezelését.

## Telepítés

1. Importáld az `database/fodrasz.sql` fájlt a phpMyAdmin segítségével.
2. Másold a `src/` mappát a webszerver könyvtárába (pl. `htdocs` XAMPP esetén).
3. A `db.php` fájlban állítsd be az adatbázis kapcsolatot.

## Admin belépési adatok

- **Email:** admin@admin.com
- **Jelszó:** admin123

## Funkciók

- Regisztráció és bejelentkezés
- Időpontfoglalás (szolgáltatás + dátum + idő)
- Saját foglalások megtekintése
- Admin: szolgáltatások és foglalások kezelése

## Könyvtárszerkezet

```
fodrasz_idopontfoglalas/
│
├── src/                # Forráskód
│   ├── db.php
│   ├── register.php
│   ├── login.php
│   ├── book.php
│   ├── admin.php
│   └── css/
│       └── style.css   # Reszponzív CSS
│
├── database/
│   └── fodrasz.sql     # Adatbázis script
│
├── docs/               # Dokumentáció
│   └── fodrasz_idopontfoglalas_dokumentacio.pdf
│
├── presentation/       # Prezentáció
│   └── fodrasz_idopontfoglalas_prezentacio.pptx
│
└── README.md           # Használati útmutató
```

## Technológia

- PHP
- MySQL
- HTML, CSS, JavaScript

## Licenc

Ez a projekt oktatási célokat szolgál és szabadon felhasználható tanuláshoz.
