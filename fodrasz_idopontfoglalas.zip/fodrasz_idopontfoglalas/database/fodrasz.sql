CREATE DATABASE IF NOT EXISTS fodrasz;
USE fodrasz;

-- Felhasználók táblája
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user','admin') DEFAULT 'user'
);

-- Szolgáltatások táblája
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    duration INT NOT NULL,
    price INT NOT NULL
);

-- Időpontok táblája
CREATE TABLE IF NOT EXISTS appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    service_id INT,
    date DATE NOT NULL,
    time TIME NOT NULL,
    status ENUM('pending','approved','cancelled') DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Admin felhasználó létrehozása (jelszó: admin123)
INSERT INTO users (name, email, password, role)
VALUES ('Admin', 'admin@admin.com', MD5('admin123'), 'admin')
ON DUPLICATE KEY UPDATE email=email;

-- Példaszolgáltatások
INSERT INTO services (name, duration, price) VALUES
('Hajvágás', 30, 5000),
('Hajfestés', 90, 12000),
('Melír', 120, 15000)
ON DUPLICATE KEY UPDATE name=name;