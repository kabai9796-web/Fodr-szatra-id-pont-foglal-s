<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    die("Először jelentkezz be! <a href='login.php'>Bejelentkezés</a>");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $service_id = intval($_POST['service_id']);
    $date = $_POST['date'];
    $time = $_POST['time'];

    $sql = "INSERT INTO appointments (user_id, service_id, date, time) VALUES ('$user_id', '$service_id', '$date', '$time')";
    if (mysqli_query($conn, $sql)) {
        $msg = "Időpont sikeresen lefoglalva!";
    } else {
        $msg = "Hiba: " . mysqli_error($conn);
    }
}

$services = mysqli_query($conn, "SELECT * FROM services");
$my = mysqli_query($conn, "SELECT a.id, s.name as service, a.date, a.time, a.status FROM appointments a JOIN services s ON a.service_id = s.id WHERE a.user_id = " . intval($_SESSION['user_id']) . " ORDER BY a.date DESC, a.time DESC");
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/style.css">
<title>Időpontfoglalás</title>
</head>
<body>
<div class="container">
  <header class="topbar">
    <h1>Időpontfoglalás</h1>
    <nav><a href="book.php">Foglalás</a> | <a href="logout.php">Kilépés</a></nav>
  </header>

  <?php if (!empty($msg)) echo "<div class='alert'>" . $msg . "</div>"; ?>

  <section class="card">
    <h2>Új foglalás</h2>
    <form method="POST" class="form grid-2">
      <label>Szolgáltatás
        <select name="service_id">
          <?php while($row = mysqli_fetch_assoc($services)) { ?>
            <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['name']) ?> (<?= $row['price'] ?> Ft)</option>
          <?php } ?>
        </select>
      </label>
      <label>Dátum
        <input type="date" name="date" required>
      </label>
      <label>Idő
        <input type="time" name="time" required>
      </label>
      <div class="actions">
        <button type="submit">Foglalás</button>
      </div>
    </form>
  </section>

  <section class="card">
    <h2>Korábbi foglalásaim</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Szolgáltatás</th><th>Dátum</th><th>Idő</th><th>Státusz</th></tr></thead>
        <tbody>
        <?php while($r = mysqli_fetch_assoc($my)) { ?>
          <tr>
            <td><?= htmlspecialchars($r['service']) ?></td>
            <td><?= htmlspecialchars($r['date']) ?></td>
            <td><?= htmlspecialchars($r['time']) ?></td>
            <td><span class="badge"><?= htmlspecialchars($r['status']) ?></span></td>
          </tr>
        <?php } ?>
        </tbody>
      </table>
    </div>
  </section>
</div>
</body>
</html>