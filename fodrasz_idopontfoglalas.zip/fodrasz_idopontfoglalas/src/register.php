<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = md5($_POST['password']); // oktatási célú egyszerűsítés

    $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
    if (mysqli_query($conn, $sql)) {
        echo "Sikeres regisztráció! <a href='login.php'>Belépés</a>";
    } else {
        echo "Hiba: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/style.css">
<title>Regisztráció</title>
</head>
<body>
<div class="container">
  <h1>Regisztráció</h1>
  <form method="POST" class="form">
    <input type="text" name="name" placeholder="Név" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Jelszó" required>
    <button type="submit">Regisztráció</button>
    <p>Már van fiókod? <a href="login.php">Bejelentkezés</a></p>
  </form>
</div>
</body>
</html>