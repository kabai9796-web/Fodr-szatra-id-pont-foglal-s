<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    die("Nincs jogosultság! <a href='login.php'>Bejelentkezés</a>");
}
if (isset($_POST['update_status'])) {
    $id = intval($_POST['id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    mysqli_query($conn, "UPDATE appointments SET status='$status' WHERE id=$id");
}

$result = mysqli_query($conn, "SELECT a.id, u.name, s.name AS service, a.date, a.time, a.status 
                               FROM appointments a
                               JOIN users u ON a.user_id = u.id
                               JOIN services s ON a.service_id = s.id
                               ORDER BY a.date DESC, a.time DESC");
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/style.css">
<title>Admin - Foglalások</title>
</head>
<body>
<div class="container">
  <header class="topbar">
    <h1>Admin felület</h1>
    <nav><a href="admin.php">Foglalások</a> | <a href="logout.php">Kilépés</a></nav>
  </header>

  <section class="card">
    <h2>Foglalások</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Név</th><th>Szolgáltatás</th><th>Dátum</th><th>Idő</th><th>Státusz</th><th>Művelet</th></tr></thead>
        <tbody>
        <?php while($row = mysqli_fetch_assoc($result)) { ?>
          <tr>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['service']) ?></td>
            <td><?= htmlspecialchars($row['date']) ?></td>
            <td><?= htmlspecialchars($row['time']) ?></td>
            <td><span class="badge"><?= htmlspecialchars($row['status']) ?></span></td>
            <td>
              <form method="POST" class="inline-form">
                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                <select name="status">
                  <option value="pending" <?= $row['status']=='pending'?'selected':'';?>>függőben</option>
                  <option value="approved" <?= $row['status']=='approved'?'selected':'';?>>jóváhagyva</option>
                  <option value="cancelled" <?= $row['status']=='cancelled'?'selected':'';?>>törölve</option>
                </select>
                <button type="submit" name="update_status">Mentés</button>
              </form>
            </td>
          </tr>
        <?php } ?>
        </tbody>
      </table>
    </div>
  </section>
</div>
</body>
</html>