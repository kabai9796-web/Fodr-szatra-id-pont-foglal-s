<?php
$host = "localhost";
$user = "root"; // XAMPP alapértelmezés
$pass = "";     // ha van jelszó, ide írd
$dbname = "fodrasz";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Adatbázis kapcsolat sikertelen: " . mysqli_connect_error());
}
?>