<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$role = $_SESSION['role'] ?? 'user';
if ($role === 'admin') {
    header("Location: admin.php");
    exit;
} else {
    header("Location: book.php");
    exit;
}